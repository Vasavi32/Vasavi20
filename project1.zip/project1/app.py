from flask import Flask, render_template,request
import numpy as np
app = Flask(__name__)
import pickle
@app.route('/')
def index():
    return render_template('index.html', my_title = 'Home')

@app.route('/myform')
def myform():
    return render_template('myform2.html', my_title = 'Home')

@app.route('/checkdata2', methods=['post'])
def checkdata2():
    return "from check data"

@app.route('/about')
def about():
    return render_template('about.html', my_title = 'About')

@app.route('/contact')
def contact():
    return render_template('contact.html', my_title = 'Contact')

@app.route('/project')
def project():
    return render_template('project.html', my_title = 'Project')

@app.route('/dform')
def dform():
    return render_template('dataform.html', my_title = 'form')

@app.route('/checkdata',methods=['post'])
def checkdata():
    ph=request.form.get('ph')
    Hardness=request.form.get('Hardness')
    Solids=request.form.get('Solids')
    Chloramines=request.form.get('Chloramines')
    Sulfate=request.form.get('Sulfate')
    Connectivity=request.form.get('Connectivity')
    Organic_Carbon=request.form.get('Organic_Carbon')
    Trihalomethanes=request.form.get('Trihalometanes')
    Turbidity=request.form.get('Turbidity')

    with open('water_model','rb') as f:
        lr2=pickle.load(f)
    new_input =np.array([[ph,Hardness,Solids,Chloramines,Sulfate,Connectivity,Organic_Carbon,Trihalomethanes,Turbidity]])
    result=lr2.predict(new_input.astype(float))
    #return result.flatten()[0]
    return render_template('result.html',prediction=result[0], my_title='Result Page')

@app.route('/result')
def result():
    return render_template('result.html', my_title = 'result')

if __name__ == '__main__':
    app.run(debug = True)